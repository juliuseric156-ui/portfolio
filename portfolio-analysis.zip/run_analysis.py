"""Reproduce pharmacy fulfillment and backtest supermarket demand. Python 3.10+."""
import csv
import sqlite3
from collections import Counter
from datetime import date, timedelta
from pathlib import Path
from statistics import mean

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
OUTPUT = ROOT / "output"


def read(name):
    with (DATA / name).open(newline="", encoding="utf-8") as source:
        return list(csv.DictReader(source))


def write(name, headers, rows):
    OUTPUT.mkdir(exist_ok=True)
    with (OUTPUT / name).open("w", newline="", encoding="utf-8") as target:
        writer = csv.writer(target)
        writer.writerow(headers)
        writer.writerows(rows)


def pharmacy():
    with sqlite3.connect(":memory:") as db:
        for name in ("medicines", "prescription_items", "medicine_dispensing", "medicine_batches"):
            rows = read(name + ".csv")
            columns = ", ".join(rows[0])
            placeholders = ", ".join("?" for _ in rows[0])
            db.execute(f"CREATE TABLE {name} ({columns})")
            db.executemany(
                f"INSERT INTO {name} VALUES ({placeholders})",
                [tuple(row.values()) for row in rows],
            )
        metrics = db.execute((ROOT / "pharmacy.sql").read_text())
        write("pharmacy_fulfillment.csv", [column[0] for column in metrics.description], metrics)
        expiry_rows = db.execute("""
            WITH batches AS (
                SELECT CASE
                    WHEN expiry_date < '2026-11-19' THEN 'Expired'
                    WHEN expiry_date <= date('2026-11-19', '+90 days') THEN 'Expires in 0–90 days'
                    ELSE 'Expires in over 90 days'
                END AS expiry_window,
                quantity_remaining * purchase_cost_per_unit_tzs AS purchase_value
                FROM medicine_batches
            )
            SELECT expiry_window, ROUND(SUM(purchase_value)) FROM batches GROUP BY expiry_window
        """)
        write("pharmacy_stock_value.csv", ["expiry_window", "purchase_value_tzs"], expiry_rows)


def supermarket():
    products = {row["product_id"]: row["product_name"] for row in read("products.csv")}
    sales = {row["sale_id"]: date.fromisoformat(row["sale_timestamp"][:10]) for row in read("sales.csv")}
    first, last = min(sales.values()), max(sales.values())
    first_monday = first + timedelta(days=(-first.weekday()) % 7)
    first_sunday = first_monday + timedelta(days=6)
    last_sunday = last - timedelta(days=(last.weekday() + 1) % 7)
    weeks = [first_sunday + timedelta(weeks=i) for i in range((last_sunday-first_sunday).days//7+1)]
    if len(weeks) < 9:
        raise ValueError("At least nine completed weeks are required.")
    units = Counter()
    for row in read("sale_items.csv"):
        day = sales[row["sale_id"]]
        sunday = day + timedelta(days=6-day.weekday())
        units[row["product_id"], sunday] += int(row["quantity"])

    target_names = {"Black tea (chai)", "Laundry soap", "Rice (mchele)"}
    product_ids = [key for key, name in products.items() if name in target_names]
    if len(product_ids) != len(target_names):
        raise ValueError("Expected all three charted products.")
    # The initial weeks compare candidates. The final four weeks stay out of model selection.
    holdout_size = 4
    methods = {
        "Previous week": lambda history: history[-1],
        "Four-week mean": lambda history: mean(history[-4:]),
    }
    summary = []
    predictions = []
    for product in product_ids:
        values = [units[product, week] for week in weeks]
        split = len(values) - holdout_size
        errors = {}
        for method, predict in methods.items():
            absolute = []
            for index in range(4, len(values)):
                forecast = predict(values[:index])
                error = abs(forecast - values[index])
                absolute.append(error)
                phase = "selection" if index < split else "holdout"
                predictions.append((products[product], weeks[index], phase, method, values[index], round(forecast, 2)))
            errors[method] = (mean(absolute[:split-4]), mean(absolute[split-4:]))
        selected = min(methods, key=lambda method: errors[method][0])
        next_week = last_sunday + timedelta(weeks=1 if last == last_sunday else 2)
        for method, predict in methods.items():
            selection_mae, holdout_mae = errors[method]
            summary.append((products[product], method, round(selection_mae, 2), round(holdout_mae, 2),
                            method == selected, next_week, round(predict(values), 2)))
    write("supermarket_backtest.csv", ["product", "week_ending", "phase", "method", "actual_units", "forecast_units"], predictions)
    write("supermarket_forecast.csv", ["product", "method", "selection_mae", "holdout_mae", "selected", "forecast_week_ending", "forecast_units"], summary)


if __name__ == "__main__":
    pharmacy()
    supermarket()
