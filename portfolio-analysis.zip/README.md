# Pharmacy and supermarket analysis

Run `python run_analysis.py` with Python 3.10 or newer. The script uses only the standard library. It writes four CSVs to `output/`, replacing any prior results.

## Pharmacy

The inputs are selected columns from hospital_data.zip. The extracts exclude patient, staff, and visit records, and omit the prescription identifiers that link items to those records. This workflow reproduces the dashboard's six fulfillment percentages and its two displayed stock values. It also reports dispensing status discrepancies by medicine. It covers these metrics, while other charts in the existing dashboard retain their existing methodology.

- medicines.csv maps each medicine ID to its generic name.
- prescription_items.csv provides the item key, medicine key, quantity prescribed, and recorded dispensing status.
- medicine_dispensing.csv provides dispensing events, item and batch keys, date, quantity, and recorded charge.
- medicine_batches.csv provides batch and medicine keys, expiry date, remaining units, and purchase cost in TZS.

The item query aggregates dispensing events first and keeps unfilled items with a left join. It caps fulfilled units per item and flags over-dispensing separately. Stock valuation uses the recorded stock snapshot as of 19 November 2026. Expired stock is before the cutoff, and upcoming expiry is within 90 days inclusive.

## Supermarket

The inputs are selected columns from supermarket_data.zip. Join sale items to transaction timestamps by sale ID and aggregate units by product and Monday–Sunday week. Drop the first partial week and the unfinished final week. A complete week with no recorded sales for a product contributes zero units.

Compare the previous week's units with a four-week trailing mean. Each prediction uses only preceding weeks. Select a model on eight earlier rolling predictions and report both models on the final four weeks, held out from selection. MAE is mean absolute error in units. The final projection for the week ending 29 November 2026 uses completed weeks only. This evaluation is separate from the earlier PDF projection. Four holdout weeks are too few to establish long-term model performance.

- products.csv maps product IDs to names.
- sales.csv provides a header and timestamp for each transaction.
- sale_items.csv provides product quantities and a transaction key.
