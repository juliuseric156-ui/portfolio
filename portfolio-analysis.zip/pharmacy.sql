WITH dispensed AS (
    SELECT prescription_item_id, SUM(CAST(quantity_dispensed AS INTEGER)) AS units
    FROM medicine_dispensing
    WHERE date_dispensed <= '2026-11-19'
    GROUP BY prescription_item_id
), items AS (
    SELECT p.medicine_id,
           CAST(p.quantity_prescribed AS INTEGER) AS prescribed,
           COALESCE(d.units, 0) AS recorded,
           p.dispensing_status
    FROM prescription_items AS p
    LEFT JOIN dispensed AS d USING (prescription_item_id)
)
SELECT m.generic_name AS medicine,
       SUM(prescribed) AS prescribed_units,
       SUM(MIN(prescribed, recorded)) AS fulfilled_units,
       SUM(MAX(0, prescribed - recorded)) AS outstanding_units,
       ROUND(100.0 * SUM(MIN(prescribed, recorded)) / SUM(prescribed), 1) AS fulfillment_pct,
       SUM(recorded > prescribed OR dispensing_status <> CASE
           WHEN recorded = 0 THEN 'Pending'
           WHEN recorded < prescribed THEN 'Partly dispensed'
           ELSE 'Fully dispensed' END) AS discrepancy_items
FROM items
JOIN medicines AS m USING (medicine_id)
GROUP BY m.medicine_id, m.generic_name
ORDER BY fulfillment_pct, medicine;
